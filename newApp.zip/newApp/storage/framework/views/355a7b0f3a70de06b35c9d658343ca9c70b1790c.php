<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php if(session()->has('error')): ?>
        <div class="fixed top-0 w-full bg-red-600 text-yellow-50 text-center h-11 py-2 shadow capitalize text-lg font-thin" id="flash_message"><?php echo e(session('error')); ?></div>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\Users\USER\Documents\laravel\laravel_menu\resources\views/components/redFlash_message.blade.php ENDPATH**/ ?>