<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> Admin Customers page </title>
</head>
<body>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <h1 class=" text-center text-xl mb-6 font-extrabold">Customers</h1>
    <div class="grid md:grid-cols-4 grid-cols-1 font-serif">
        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class=' h-auto bg-blue-100 shadow-2xl mr-8 px-2'>
        <div class=' flex justify-between capitalize'><h3 class="">name</h3> <span><?php echo e($customers->name); ?></span></div>
        <div class=' flex border-t border-white justify-between capitalize'> <h3 class=" ">username</h3> <span><?php echo e($customers->username); ?></span></div>
        <div class=' flex border-t border-white justify-between capitalize'> <h3 class="">email</h3> <span ><?php echo e($customers->email); ?></span></div>
        <address class=' flex border-t border-white justify-between capitalize'><h3 class="">address</h3> <span class=""><?php echo e($customers->address); ?></span></address>
        <div class=' flex border-t border-white justify-between capitalize'> <h3 class="">Register date</h3> <span><?php echo e($customers->created_at); ?></span></div>
      </div>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

</body>
</html><?php /**PATH C:\Users\USER\Documents\laravel\laravel_menu\resources\views/admin/customers.blade.php ENDPATH**/ ?>