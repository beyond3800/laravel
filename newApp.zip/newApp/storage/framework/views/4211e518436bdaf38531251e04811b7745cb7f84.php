<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        
        <div class=" mt-3 py-2 bg-red-300">
            <div class=" w-full h-auto flex justify-center">
                <div class=" md:w-5/12 h-52">
                    <img 
                    src="<?php echo e($viewed['image'] ? asset('storage/' . $viewed['image']) : asset('image/IMG_1061.jpeg')); ?>" alt="" class="w-full h-full">
                </div>
            </div>
            <div class=" text-center mt-5 md:px-80">
                <p class=" uppercase font-serif border-b"><?php echo e($viewed->product_name); ?></p>
                <p class="border-b"><?php echo e($viewed->description); ?></p>
                <p class="border-b"><?php echo e($viewed->short_desc); ?></p>
                <p class="border-b ">#<?php echo e($viewed->price); ?></p>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
     
</body>
</html><?php /**PATH C:\Users\USER\Documents\laravel\laravel_menu\resources\views/show/index.blade.php ENDPATH**/ ?>