<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    
        
        
    <tr class=" text-center capitalize  border-b">
        <td><?php echo e($admin->username); ?></td>
        <td><?php echo e($admin->email); ?></td>
        <td><address>empty</address></td>
        <td> empty</td>
        <td><?php echo e($admin->role); ?></td>
        <td class=" capitalize flex"> 
            <a href="/admin/edit-admin/<?php echo e($admin->id); ?>" class="mr-2 capitalize border rounded-lg px-1 text-sm bg-green-400 hover:bg-green-600">edit</a>
            <form action="/admin/delete-admin/<?php echo e($admin->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="capitalize border rounded-lg px-1 text-sm bg-red-400 hover:bg-red-600">delete</button>
            </form>
        </td>
    </tr>
</body>
</html><?php /**PATH C:\Users\USER\Documents\laravel\laravel_menu\resources\views/components/eachAdmin.blade.php ENDPATH**/ ?>