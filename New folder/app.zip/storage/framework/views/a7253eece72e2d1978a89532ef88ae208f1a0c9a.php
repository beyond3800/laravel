
<div class=" flex flex-col items-center">
 <div class="bg-gray-100 pt-4 pb-4 px-4 sm: mx-10  md:w-3/12 shadow-xl ">
    <?php echo e($slot); ?>

 </div>
</div><?php /**PATH C:\Users\USER\Documents\laravel\laravel_menu\resources\views/components/formCard.blade.php ENDPATH**/ ?>