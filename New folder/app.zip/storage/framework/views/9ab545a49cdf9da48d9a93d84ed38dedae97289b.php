
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders</title>
    
</head>
<body>
    <?php
        $orderLenght = count($usersOrders);
        $totalAmount = 0;
        $totalQuatity =0;
        foreach ($usersOrders as $usersOrder) {
            $totalAmount += $usersOrder['price']*$usersOrder['quatity'];
            $totalQuatity +=$usersOrder['quatity'];
        }
    ?>
 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <div class=" w-full pb-5">
    <?php if(auth()->guard()->check()): ?>
    <div class=" text-center capitalize"> <?php echo e(auth()->user()->username); ?></div>
     
    <?php if($orderLenght <= 0): ?>
      <div class=" text-center text-lg font-semibold">You've not order any food yet</div>
    <?php endif; ?>

    <div class="grid grid-cols-1 md:grid-cols-2 md:pl-5 md:pr-24 pr-5"
    >
    <?php $__currentLoopData = $usersOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.eachOrder','data' => ['data' => $userOrder]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('eachOrder'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($userOrder)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php else: ?>
      <div class=" text-center text-lg font-semibold">You are not logged in</div>
    <?php endif; ?>
  </div>
  <?php if($orderLenght > 0): ?>
  <?php if(auth()->guard()->check()): ?>
    <div class="mb-2 text-center"> <address>Address : <?php echo e(auth()->user()->address); ?></address></div>
    <form action="/checkout-address" method="post" class="text-center">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <label for="address" class=" font-bold">Change Address :</label>
        <input type="hidden" name="user_id" id="" value="<?php echo e(auth()->user()->id); ?>">
        <input type="text" id="address" placeholder="" class=" border rounded-md pl-3" name="address" value="<?php echo e(auth()->user()->address); ?>">
        <button type="submit" class=" border rounded-md px-1 shadow">change</button>
    </form>
  <?php endif; ?>
  <div class=" mt-11">
    <div class="text-center">Delivery Fees : #1000</div>
      <div class=" text-center">Total Amount: <span>#<?php echo e($totalAmount); ?></span></div>
      
   <div class="flex justify-center">
      <form action="/checkout-order" method="post" class="">
       <?php echo csrf_field(); ?>
       <?php echo method_field('put'); ?>
       <button type="submit" class=" bg-transparent border px-2 rounded-xl font-serif hover:bg-green-600 hover:text-white shadow-xl">Checkout Order</button>
      </form>
      <form action="/clear-order" method="post" class="ml-10">
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
       <button type="submit" class=" bg-transparent border px-2 rounded-xl font-serif hover:bg-red-600 hover:text-white shadow-xl">Clear Order</button>
      </form>  
   </div>

  </div>
  <?php endif; ?>
  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</body>
</html><?php /**PATH C:\Users\USER\Documents\laravel\laravel_menu\resources\views//order/index.blade.php ENDPATH**/ ?>