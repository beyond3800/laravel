<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Each data</title>
</head>
<body>
    <?php
        $admin = auth()->guard('admin')->user();
        if($admin){
            $adminName = $admin->name;
        }else{
            $adminName = '';
        }
        $user = auth()->user()?auth()->user()->id:'';

    ?>
    <?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['data']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['data']); ?>
<?php foreach (array_filter((['data']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="flex bg-white mt-2 mb-10 md:mr-20 md: ml-10 shadow-lg border-t">
        <div class="h-40 w-72 rounded py-2  ">
           <img 
           class="w-full h-full rounded border-4 border-yellow-500" 
           src="<?php echo e($data->image ? asset('storage/' . $data->image) : asset('image/IMG_1061.jpeg')); ?>" alt=""> 
        </div>
    <div class="grid-cols-4 mt-3 ml-5 md:w-40">
        <div class="flex w-full justify-between items-center pr-2 ">
            <p class="border-b border-dashed border-b-gray-600">
            <span class="text-gray-500 text-sm"><?php echo e($data->product_name); ?></span></p> 
            <p class="text-sm">$<?php echo e($data->price); ?></p> 
        </div>
            <p class="mt-2"><?php echo e($data->category); ?></p>
            
        <div class=" flex justify-between items-center">
            <form method="GET" action="show/index/<?php echo e($data->menu_id); ?>" class="mt-2" >
                <?php echo csrf_field(); ?>
                <button
                class=" border-2 rounded-md border-gold px-1 capitalize text-xs font-mono hover:text-gray-100 hover:bg-gold"
                id="orderBtn">view</button>
            </form>
        <?php if(!$adminName): ?>
        <div class=" flex items-center justify-center mt-3">
            <form method="POST" action="add_order/<?php echo e($data->id); ?>" class="" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
             <input type="hidden" name="order_id" value="<?php echo e($data->menu_id); ?>">
                <button
                class=" border-2 rounded-md border-gold px-1 capitalize text-xs font-mono hover:text-white hover:bg-green-600 mb-1"
                id="orderBtn">+</button>
            </form>
                <input type="text" name="" id="" class=" w-10 border h-4 border-l-0 border-r-0 text-center text-sm" value="<?php echo e($data->quatity); ?>">
            <?php if($data->quatity<=1): ?>
                <form method="POST" action="/order_deleted/<?php echo e($data->id); ?>}" class="" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button
                    class=" border-2 rounded-md border-gold px-1 capitalize text-xs font-mono bg-red-400 mb-1"
                    id="orderBtn">-</button>
                </form>
             <?php else: ?>
                <form method="POST" action="remove_order/<?php echo e($data->id); ?>" class="" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="order_id" value="<?php echo e($data->menu_id); ?>">
                    <button class=" border-2 rounded-md border-gold px-1 capitalize text-xs font-mono hover:text-black-100 hover:bg-red-600 mb-1 text-black "
                     id="orderBtn">-</button>
                </form>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
    <form method="POST" action="/order_deleted/<?php echo e($data->id); ?>}" class="" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button
        class=" border-2 rounded-md border-gold px-1 capitalize text-xs font-mono bg-red-100 mt-5 hover:bg-red-300"
        id="orderBtn">deleteOrder</button>
    </form>
</div>
</body>
</html><?php /**PATH C:\Users\USER\Documents\laravel\laravel_menu\resources\views/components/eachOrder.blade.php ENDPATH**/ ?>